import 'dart:io';

void main(){
  List<int> num=[12,4,1,2,1,2,2,4];
  print('Rsult are in store num : $num');

  Map<String,String> phonPric={'poco':'12000', 'relme':'14025'};
  print("phone price store: $phonPric");
}