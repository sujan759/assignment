import 'dart:io';
void main(){
  
  for(int i=1;i<=5;i++){
    print("$i sujan");
  }
}