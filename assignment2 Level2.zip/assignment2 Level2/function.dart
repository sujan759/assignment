
import 'dart:io';

//  input function

String strinValue()=>stdin.readLineSync()!;
num numValue()=>num.parse(strinValue());
int intValue()=>int.parse(strinValue());
double doubleValue()=>double.parse(strinValue());


